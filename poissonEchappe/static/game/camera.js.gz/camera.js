class Camera {
 
    constructor(gameWidth, gameHeight) {
        this.camx = 0;
    }

    update(camx) {
        this.camx = camx;
    }
}