class State {
    constructor(state) {
        this.state = state;
    }

    setState(state) {
        this.state = state;
    }
}